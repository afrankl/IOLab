require 'test_helper'

class CoordinateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
