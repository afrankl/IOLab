require 'test_helper'

class StreetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
