require 'test_helper'

class IntersectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
