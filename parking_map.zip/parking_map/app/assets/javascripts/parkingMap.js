var map;

var initialize = function() {
	var mapDiv = document.getElementById('map');
	var initSettings = {
		center: {lat: 37.870614, lng: -122.262302},
		zoom: 14,
	};
	map = new google.maps.Map(mapDiv, initSettings);
	map.setOptions({
	    scrollwheel: false,
	    mapTypeId: google.maps.MapTypeId.ROADMAP
	});
	$.ajax({
			type: 'GET',
			url: '/get_zones',
			success: function(data) {
				// google.maps.event.addDomListener(map, 'mousemove', closeInfoWindow);
				collection = new ZoneCollection(['Berkeley Regions', 'Max Time', 'Parking Rates', 'Types']);
				for (var key in data) {
					var zone = new Zone(data[key]);
					collection.add(zone);
				}
				collection.draw();
			}
		});
	}


var findInMap = function() {
		getLocation($('#street-group input').val());
	};

var getLocation = function(street) {
	var data = {
		address: street,
		key: 'AIzaSyC4vIrGjZOObvvcbFrSshhJpRomRSRXwbY'
	}
	$.ajax({
			type: 'GET',
			url: 'https://maps.googleapis.com/maps/api/geocode/json?',
			data: data,
			success: function(data) {
				var latLong = data.results[0].geometry.location;
				zoomMap(latLong);
			}
		});
	};

var zoomMap = function(latLong) {
	map.setOptions({
		center: latLong,
		zoom: 17,
	});
};

var closeInfoWindow = function(event) {
	if (currentWindow) {
		currentWindow.close()
	}
}

google.maps.event.addDomListener(window, "load", initialize);
