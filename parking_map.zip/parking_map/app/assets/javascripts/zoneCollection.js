var collection;

var ZoneCollection = function(fields) {
	this.zones = [];
	this.fields = fields;
	this.showing = fields;
	var filters = {};
	this.showing.forEach(function(field) {
		filters[field] = 'All';
	});

	this.setFilters = function(key, value) {
		filters[key] = value;
	}
	this.getFilters = function() {
		return filters;
	}
}

ZoneCollection.prototype.initFilters = function() {
	var filters = {}
	this.showing.forEach(function(field) {
		filters[field] = 'All';
	});
	return filters;
}

ZoneCollection.prototype.add = function(zone) {
	this.zones.push(zone);
}

ZoneCollection.prototype.remove = function(zone) {
	for (var i = 0; i < this.zones.length ; i++) {
		var item = this.zones[i];
		if (item.id == zone.id) {
			this.zones.splice(i, 1);
		}
	}
}

ZoneCollection.prototype.draw = function() {
	this.zones.forEach(function(zone) {
		zone.draw();
	})
}

ZoneCollection.prototype.filter = function(menu, value) {
	if (currentWindow) {
		currentWindow.close();
	}
	
	for (var key in this.getFilters()) {
		this.zones.forEach(function(zone) {
			zone.applyFilter(menu, value);
		});
	}
}