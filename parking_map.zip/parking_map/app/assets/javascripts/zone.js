var selectedZone;
var strokeOpacity =.8;
var fillOpacity = .35;
var strokeWeight = 2;
var currentWindow;

var filterMap = {
	"Types": "category",
	"Max Time": "time", 
	"Berkeley Regions": "region",
	"Parking Rates": "rate",
}

function Zone(data) {
	var values = {}
	for (var key in data) {
		this[key] = data[key];
		values[key] = data[key];
	}

	var colors = {
		"Premium": '#FF0000',
		"Value": '#00FF00',
		"Lot": '#0000FF',
	}

	calculateMiddle = function() {
		
	}

	this.strokeColor = colors[this.category];
	this.fillColor = colors[this.category];
	this.strokeWeight = strokeWeight;
	this.strokeOpacity = strokeOpacity;
	this.fillOpacity = fillOpacity;
	this.hidden = true;
	var isOpen = false;
	var region_html = "<div>"+ "Region: " + values.region +"</div>";
	var rate_html = "<div>"+ "Parking Rate: " + values.rate +"</div>";
	var time_html = "<div>"+ "Max Time: " + values.time +"</div>";
	var types_html = "<div>"+ "Type: " + values.category +"</div>" 
	var contentString = region_html + rate_html + time_html + types_html;
	var infoWindow = new google.maps.InfoWindow({
    		content: contentString
  	});

    this.mouseOverEvent = function(event) {
    	if (currentWindow) {
    		currentWindow.close();
    	}
    	var lat = 0;
		var lng = 0;
		for (var i = 0; i < values.locations.length; i++) {
			var latLng = values.locations[i];
			lat += latLng.lat;
			lng += latLng.lng;
		}
    	infoWindow.open(map);
    	infoWindow.setPosition({
			"lat": lat / values.locations.length,
			"lng": lng / values.locations.length
		});
    	currentWindow = infoWindow;
    }


	this.clickEvent = function(event) {
		var elements = {};

		for (field in values) {
			var key = '#zone-' + field;
			elements[key] = values[field];
		}

		for (var key in elements) {
			data = elements[key];
			var info_tag = $(key).find('.info');
			if (info_tag.children().length > 0) {
				info_tag.empty();
			}
			info_tag.append($("<div>" + data + "</div>" ));
		}
	}

	var p = {
		paths: this.locations,
	    strokeColor: this.strokeColor,
	    strokeOpacity: this.strokeOpacity,
	    strokeWeight: this.strokeWeight,
	    fillColor: this.fillColor,
	    fillOpacity: this.fillOpacity,
	};
	this.polygon = new google.maps.Polygon(p);
}

Zone.prototype.addListeners = function() {
	this.polygon.addListener('click', this.clickEvent);
	this.polygon.addListener('mouseover', this.mouseOverEvent);
}

Zone.prototype.clearListeners = function() {
	google.maps.event.clearInstanceListeners(this.polygon);
}


Zone.prototype.draw = function(){
	this.polygon.setMap(map);
	this.addListeners();
	this.hidden = false;
}

Zone.prototype.show = function(show) {
	if (show) {
		this.strokeOpacity = strokeOpacity;
		this.fillOpacity = fillOpacity;
		this.addListeners();

		if (this.hidden) {
			this.update();
			this.hidden = !this.hidden;

		}
	} else {
		this.strokeOpacity = 0;
		this.fillOpacity = 0;
		this.clearListeners();
		if (!this.hidden) {
			this.update();
			
			this.hidden = !this.hidden;
		}
	}
}

Zone.prototype.applyFilter = function(filter, value) {
	if (value === 'All') {
		this.show(true);
	} else {
		var filterType = filterMap[filter];
		if (filterType === "rate") {
			this.show(parseFloat(value) + .01 > parseFloat(this[filterType]));
		} else if (filterType === "time") {
			this.show(parseFloat(value) - .01 <= parseFloat(this[filterType]))
		} else {
			this.show(this[filterType] === value)
		}
	}
}

Zone.prototype.update = function() {
	var p = {
		paths: this.locations,
	    strokeColor: this.strokeColor,
	    strokeOpacity: this.strokeOpacity,
	    strokeWeight: this.strokeWeight,
	    fillColor: this.fillColor,
	    fillOpacity: this.fillOpacity,
	};
	this.polygon.setOptions(p);
}