class ParkingController < ApplicationController
  def index
  	@regions = ['All', 'Downtown', 'Southside', 'Northside', 'Campus', 'Other']
   	@intervals = ['All', '1', '2', '2.5', '3', '4', '8']
   	@rates = ['All','1', '1.50', '2', '2.50', '3.00']
    @categories = ['All','Premium', 'Value', 'Lot']
   	@dropdowns = {'Berkeley Regions' => {:data => @regions, :prefix => '', :suffix => ''},
   				        'Max Time' => {:data => @intervals, :prefix => '', :suffix => ' Hours'},
   				        'Parking Rates' => {:data => @rates, :prefix => '$', :suffix => ''},
                  'Types' => {:data => @categories, :prefix => '', :suffix => ''}
                }
    @show_checkboxes = ['Regions', 'Max Time', 'Parking Rates', 'Types']
  end

  def get_zones
  	@zones = Zone.all
  	@data = {}
  	@zones.each do |zone|
  		data = {
        :id => zone.id,
  			:category => zone.category,
  			:rate => zone.rate,
  			:time => zone.time,
        :region => zone.region,
  			:locations => []
  		}
  		zone.intersections.each do |intersection|
  			coordinate_id = intersection.location
  			coordinate = Coordinate.where(:id => coordinate_id).first
  			data[:locations] << {
  				:lat => coordinate.lat,
  				:lng => coordinate.lng
  			}
  		end
  		@data[zone.id] = data
  	end
  	render json: @data, status: 278
  end
end
