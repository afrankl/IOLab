class Coordinate < ActiveRecord::Base
	belongs_to :intersection
	belongs_to :street
end
