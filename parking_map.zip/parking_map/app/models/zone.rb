class Zone < ActiveRecord::Base
	has_many :intersections
	
	def self.create_streets(data)
		streets = data.delete(:streets)
		zone = Zone.create(data)
		[streets[:east], streets[:west]].each do |side|
			intersection = Intersection.create(:street1 => streets[:north], :street2 => side)
			intersection.location = intersection.geolocate
			zone.intersections << intersection
		end
		[streets[:west], streets[:east]].each do |side|
			intersection = Intersection.create(:street1 => streets[:south], :street2 => side)
			intersection.location = intersection.geolocate
			zone.intersections << intersection
		end
		zone.save()
		return zone
	end



	def self.create_intersections(data)
		intersections = data.delete(:intersections)
		zone = Zone.create(data)
		zone.intersections << intersections
		zone.save()
		return zone
	end





end
