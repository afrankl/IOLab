class Street < ActiveRecord::Base
  has_many :coordinates
  def address
  	return self.name + " " + self.city + ", " + self.state
  end
end
