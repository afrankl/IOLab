require 'net/http'
require 'json'

class Intersection < ActiveRecord::Base
	belongs_to :zone
	has_one :coordinate
	def geolocate
		base = 'https://maps.googleapis.com/maps/api/geocode/json?'
		address = self.street1.name + " and " + self.street2.name + ", " + self.street2.city + " " + self.street2.state
		key = 'AIzaSyC4vIrGjZOObvvcbFrSshhJpRomRSRXwbY'
		url = URI.parse(base + 'address=' + address + '&key=' + key)
		req = Net::HTTP::Get.new(url.to_s)
		http = Net::HTTP.new(url.host, url.port)
		http.use_ssl = true
		res = http.request(req)
		if res.code == "200"
			res = JSON.parse(res.body)
			return Coordinate.create(res["results"][0]["geometry"]["location"])

		else
			return false
		end
	end

	def self.create_streets street1, street2
		intersection = Intersection.create(:street1 => street1, :street2 => street2)
		intersection.location = intersection.geolocate
		intersection.save()
		return intersection
	end

	def self.create_coordinates street1, street2, lat, lng
		intersection = Intersection.create(:street1 => street1, :street2 => street2)
		intersection.location = Coordinate.create(:lat => lat, :lng => lng)
		intersection.save()
		return intersection
	end

end
