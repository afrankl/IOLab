# Be sure to restart your server when you modify this file.

# Version of your assets, change this if you want to expire all your assets.
Rails.application.config.assets.version = '1.0'

# Add additional assets to the asset load path
# Rails.application.config.assets.paths << Emoji.images_path

# Precompile additional assets.
# application.js, application.css, and all non-JS/CSS in app/assets folder are already added.
# Rails.application.config.assets.precompile += %w( search.js )

Rails.application.config.assets.precompile += %w( parkingMap.js )
Rails.application.config.assets.precompile += %w( zone.js )

Rails.application.config.assets.precompile += %w( header.scss )
Rails.application.config.assets.precompile += %w( parking.scss )
Rails.application.config.assets.precompile += %w( map.scss )
Rails.application.config.assets.precompile += %w( street_inputs.scss )
Rails.application.config.assets.precompile += %w( dropdowns.scss )
Rails.application.config.assets.precompile += %w( parking_details.scss )
