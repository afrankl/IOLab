class CreateStreets < ActiveRecord::Migration
  def change
    create_table :coordinates do |t|
      t.float :lat
      t.float :lng
    end
    create_table :streets do |t|
      t.text :name
      t.string :city
      t.string :state
      t.timestamps null: false
    end
    create_table :intersections do |t|
      t.timestamps null: false
    end
    add_column :intersections, :street1, :street
    add_column :intersections, :street2, :street
    add_column :intersections, :location, :coordinate
    
    create_table :zones do |t|
      t.timestamps null: false
      t.string :category
      t.float :rate
      t.float :time
      t.string :region
    end
    add_reference :intersections, :zone, index: false
    add_reference :coordinates, :intersection, index: false
  end
end
