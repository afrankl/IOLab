# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

hearst = Street.create(:name => "Hearst Ave", :city => "Berkeley", :state => "CA")
bancroft = Street.create(:name => "Bancroft Way", :city => "Berkeley", :state => "CA")
mlk = Street.create(:name => "Martin Luther King Jr. Way", :city => "Berkeley", :state => "CA")
oxford = Street.create(:name => "Oxford Street", :city => "Berkeley", :state => "CA")
fulton = Street.create(:name => "Fulton Street", :city => "Berkeley", :state => "CA")

berkeleyway = Street.create(:name => "Berkeley Way", :city => "Berkeley", :state => "CA")
milvia = Street.create(:name => "milvia Street", :city => "Berkeley", :state => "CA")
shattuck = Street.create(:name => "Shattuck Ave", :city => "Berkeley", :state => "CA")


hearst_oxford = Intersection.create_streets(hearst, oxford)
bancroft_fulton = Intersection.create_streets(bancroft, fulton)
mlk_bancroft = Intersection.create_streets(mlk, bancroft)
mlk_hearst = Intersection.create_streets(mlk, hearst)
d1 = Zone.create_intersections({
  :intersections => [ mlk_hearst, hearst_oxford, bancroft_fulton, mlk_bancroft ],
  :rate => 2.75, 
  :category => "Premium",
  :time => 2,
  :region => 'Downtown' })

# hearst = Street.create(:name => "Hearst Ave", :city => "Berkeley", :state => "CA")
# bancroft = Street.create(:name => "Bancroft Way", :city => "Berkeley", :state => "CA")
# mlk = Street.create(:name => "Martin Luther King Jr. Way", :city => "Berkeley", :state => "CA")
# oxford = Street.create(:name => "Oxford Street", :city => "Berkeley", :state => "CA")
# fulton = Street.create(:name => "Fulton Street", :city => "Berkeley", :state => "CA")

# hearst_oxford = Intersection.create_streets(hearst, oxford)
# bancroft_fulton = Intersection.create_streets(bancroft, fulton)
# mlk_bancroft = Intersection.create_streets(mlk, bancroft)
# mlk_hearst = Intersection.create_streets(mlk, hearst)
# d1 = Zone.create_intersections({
#   :intersections => [ mlk_hearst, hearst_oxford, bancroft_fulton, mlk_bancroft ],
#   :rate => 2.75, 
#   :category => "Premium",
#   :time => 2,
#   :region => 'Downtown' })



berkeleyway_milvia = Intersection.create_coordinates(berkeleyway, milvia, 37.872769, -122.270127)
berkeleyway_milvia2 = Intersection.create_coordinates(berkeleyway, milvia, 37.872401, -122.270063)
berkeleyway_shattuck = Intersection.create_coordinates(berkeleyway, shattuck, 37.872922, -122.269077)
berkeleyway_shattuck2 = Intersection.create_coordinates(berkeleyway, shattuck, 37.872535, -122.268994)

# d3 = Zone.create_intersections({
#   :intersections => [berkeleyway_shattuck2, berkeleyway_milvia2, berkeleyway_milvia, berkeleyway_shattuck],
#   :rate => 1.50,
#   :category => "Value",
#   :time => 8,
#   :region => "Downtown"
#   })



dwight = Street.create(:name => "Dwight Way", :city => "Berkeley", :state => "CA")
d3 = Zone.create_streets({:streets => {
      :north => bancroft,
      :south => dwight,
      :east => fulton,
      :west => milvia},
  :rate => 1.50,
  :category => "Value",
  :time => 8,
  :region => "Downtown"
  })



channing = Street.create(:name => "Channing Way", :city => "Berkeley", :state => "CA")
piedmont = Street.create(:name => "Piedmont Avenue", :city => "Berkeley", :state => "CA")
bancroft_fulton = Intersection.create_streets(bancroft, fulton)
bancroft_piedmont = Intersection.create_streets(bancroft, piedmont)
piedmont_channing = Intersection.create_coordinates(piedmont, channing, 37.867788, -122.252033)
channing_fulton = Intersection.create_streets(channing, fulton)
s1 = Zone.create_intersections({
  :intersections => [bancroft_fulton, bancroft_piedmont, piedmont_channing, channing_fulton],
  :rate => 2.75,
  :category => "Premium",
  :time => 2, 
  :region => 'Southside' })


college = Street.create(:name => "College Avenue", :city => "Berkeley", :state => "CA")
dana = Street.create(:name => "Dana Street", :city => "Berkeley", :state => "CA")
s2 = Zone.create_streets({:streets => {
      :north => channing,
      :south => dwight,
      :east => college,
      :west => dana},
  :rate => 1.50,
  :category => "Value",
  :time => 8,
  :region => "Southside"
  })


stuart = Street.create(:name => "Stuart Street", :city => "Berkeley", :state => "CA")
webster = Street.create(:name => "Webster Street", :city => "Berkeley", :state => "CA")
benvenue = Street.create(:name => "Benvenue Avenue", :city => "Berkeley", :state => "CA")
stuart_benvenue = Intersection.create_streets(stuart, benvenue)
stuart_piedmont = Intersection.create_streets(stuart, piedmont)
piedmont_webster = Intersection.create_coordinates(piedmont, webster, 37.855925, -122.250511)
webster_benvenue = Intersection.create_streets(webster, benvenue)
e1 = Zone.create_intersections({
  :intersections => [stuart_benvenue, stuart_piedmont, piedmont_webster, webster_benvenue],
  :rate => 1.50, 
  :category => "Value",
  :time => 3,
  :region => 'Elmwood' })


rose = Street.create(:name => "Rose Street", :city => "Berkeley", :state => "CA")
n1 = Zone.create_streets({:streets => {
      :north => rose,
      :south => hearst,
      :east => oxford,
      :west => milvia},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Northside"
  })



the_alameda = Street.create(:name => "The Alameda", :city => "Berkeley", :state => "CA")
tulare = Street.create(:name => "Tulare Street", :city => "Berkeley", :state => "CA")
ensenada = Street.create(:name => "Ensenada Ave", :city => "Berkeley", :state => "CA")
marin = Street.create(:name => "Marin Ave", :city => "Berkeley", :state => "CA")
tacoma = Street.create(:name => "Tacoma Ave", :city => "Berkeley", :state => "CA")
catalina = Street.create(:name => "Catalina Ave", :city => "Berkeley", :state => "CA")
colusa = Street.create(:name => "Colusa Ave", :city => "Berkeley", :state => "CA")
solano = Street.create(:name => "Solano Ave", :city => "Berkeley", :state => "CA")
ensenada_tacoma = Intersection.create_streets(ensenada, tacoma)
tacoma_colusa = Intersection.create_streets(tacoma, colusa)
colusa_catalina = Intersection.create_streets(colusa, catalina)
catalina_the_alameda = Intersection.create_streets(catalina, the_alameda)
the_alameda_marin = Intersection.create_streets(the_alameda, marin)
marin_tulare = Intersection.create_streets(marin, tulare)
solano_tulare = Intersection.create_streets(solano, tulare)

solano_zone = Zone.create_intersections({
  :intersections => [ensenada_tacoma, tacoma_colusa, colusa_catalina, catalina_the_alameda, the_alameda_marin, marin_tulare, solano_tulare], 
  :rate => 1.50, 
  :category => "Value",
  :time => 2,
  :region => 'Other' })




telegraph = Street.create(:name => "Telegraph Ave", :city => "Berkeley", :state => "CA")
woolsey = Street.create(:name => "Woolsey Street", :city => "Berkeley", :state => "CA")
regent = Street.create(:name => "Regent Street", :city => "Berkeley", :state => "CA")
ashby = Street.create(:name => "Ashby Ave", :city => "Berkeley", :state => "CA")
prince = Street.create(:name => "Prince Street", :city => "Berkeley", :state => "CA")
blake = Street.create(:name => "Blake Street", :city => "Berkeley", :state => "CA")

telegraph_zone = Zone.create_streets({:streets => {
      :north => dwight,
      :south => woolsey,
      :east => regent,
      :west => telegraph},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Southside"
  })


ward = Street.create(:name => "Ward Street", :city => "Berkeley", :state => "CA")
essex = Street.create(:name => "Essex Street", :city => "Berkeley", :state => "CA")
adeline = Street.create(:name => "Adeline Street", :city => "Berkeley", :state => "CA")
adeline_zone = Zone.create_streets({:streets => {
      :north => ward,
      :south => essex,
      :east => shattuck,
      :west => adeline},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Other"
  })




russel = Street.create(:name => "Russel Street", :city => "Berkeley", :state => "CA")
domingo = Street.create(:name => "Domingo Ave", :city => "Berkeley", :state => "CA")
claremont = Street.create(:name => "Claremont Ave", :city => "Berkeley", :state => "CA")
claremont_zone = Zone.create_streets({:streets => {
      :north => russel,
      :south => ashby,
      :east => domingo,
      :west => claremont},
  :rate => 1.50,
  :category => "Value",
  :time => 1,
  :region => "Other"
  })



leconte = Street.create(:name => "Le Conte Ave", :city => "Berkeley", :state => "CA")
gayley = Street.create(:name => "Gayley Road", :city => "Berkeley", :state => "CA")
scenic = Street.create(:name => "Scenic Ave", :city => "Berkeley", :state => "CA")
laloma = Street.create(:name => "La Loma Ave", :city => "Berkeley", :state => "CA")
spruce = Street.create(:name => "Spruce Street", :city => "Berkeley", :state => "CA")

hearst_leconte = Intersection.create_streets(hearst, leconte)
leconte_scenic = Intersection.create_coordinates(leconte, scenic, 37.876703, -122.262032)
leconte_laloma = Intersection.create_streets(leconte, laloma)
laloma_hearst = Intersection.create_streets(laloma, hearst)
hearst_spruce = Intersection.create_streets(hearst, spruce)

north_campus = Zone.create_intersections({
  :intersections => [hearst_leconte, leconte_scenic, leconte_laloma, 
                  laloma_hearst, hearst_leconte, hearst_spruce],
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Campus"
  })



sanpablo = Street.create(:name => "San Pablo Ave", :city => "Berkeley", :state => "CA")
harrison = Street.create(:name => "Harrison Street", :city => "Berkeley", :state => "CA")
heinz = Street.create(:name => "Heinz Ave", :city => "Berkeley", :state => "CA")
sanpablo_zone = Zone.create_streets({:streets => {
      :north => harrison,
      :south => heinz,
      :east => sanpablo,
      :west => sanpablo},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Other"
  })




ninth = Street.create(:name => "9th Street", :city => "Berkeley", :state => "CA")
tenth = Street.create(:name => "10th Street", :city => "Berkeley", :state => "CA")
camelia = Street.create(:name => "Camelia Street", :city => "Berkeley", :state => "CA")
gilman = Street.create(:name => "Gilman Street", :city => "Berkeley", :state => "CA")
gilman_zone = Zone.create_streets({:streets => {
      :north => gilman,
      :south => camelia,
      :east => tenth,
      :west => ninth},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Other"
  })


fourth = Street.create(:name => "4th Street", :city => "Berkeley", :state => "CA")
virginia = Street.create(:name => "Virginia Street", :city => "Berkeley", :state => "CA")
fourth_zone = Zone.create_streets({:streets => {
      :north => virginia,
      :south => hearst,
      :east => fourth,
      :west => fourth},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Other"
  })



addison = Street.create(:name => "Addison Street", :city => "Berkeley", :state => "CA")
fourth_zone = Zone.create_streets({:streets => {
      :north => hearst,
      :south => addison,
      :east => mlk,
      :west => fourth},
  :rate => 1.50,
  :category => "Value",
  :time => 2,
  :region => "Other"
  })




















