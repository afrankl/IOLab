# parking_map

Heroku: https://parkingmap.herokuapp.com/

To run locally do the following...

1) Make sure postgresql is installed on your local machine
2) reinstall/install ruby 2.2.3 with a --disable-binaries flag
    a) rvm reinstall 2.2.3 --disable-binaries
        or
    b) rvm install 2.2.3 --disable-binaries
3) run the following commands in the parking_map directory
    a) bundle install
    b) bundle exec rake db:migrate db:seed
    c) bundle exec rails server
